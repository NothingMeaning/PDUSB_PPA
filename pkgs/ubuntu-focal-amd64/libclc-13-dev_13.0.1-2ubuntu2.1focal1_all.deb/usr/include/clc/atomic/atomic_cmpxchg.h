_CLC_OVERLOAD _CLC_DECL int atomic_cmpxchg (volatile local int *, int, int);
_CLC_OVERLOAD _CLC_DECL int atomic_cmpxchg (volatile global int *, int, int);
_CLC_OVERLOAD _CLC_DECL uint atomic_cmpxchg (volatile local uint *, uint, uint);
_CLC_OVERLOAD _CLC_DECL uint atomic_cmpxchg (volatile global uint *, uint, uint);
