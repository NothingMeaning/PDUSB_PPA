_CLC_DECL _CLC_OVERLOAD void barrier(cl_mem_fence_flags flags);
