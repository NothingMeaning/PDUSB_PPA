_CLC_OVERLOAD _CLC_DECL int atom_inc(volatile global int *p);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_inc(volatile global unsigned int *p);
