_CLC_DECL _CLC_OVERLOAD void wait_group_events(int num_events,
                                               event_t *event_list);
