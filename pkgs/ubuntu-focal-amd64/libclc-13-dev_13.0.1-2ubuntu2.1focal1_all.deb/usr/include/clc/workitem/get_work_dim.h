_CLC_DECL _CLC_OVERLOAD uint get_work_dim(void);
