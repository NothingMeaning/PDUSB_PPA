_CLC_DECL _CLC_OVERLOAD size_t get_global_size(uint dim);
