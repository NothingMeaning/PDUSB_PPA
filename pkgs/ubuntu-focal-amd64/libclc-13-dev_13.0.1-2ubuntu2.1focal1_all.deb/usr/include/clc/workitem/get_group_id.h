_CLC_DECL _CLC_OVERLOAD size_t get_group_id(uint dim);
