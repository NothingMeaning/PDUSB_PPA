#define __CLC_BODY <clc/integer/mul_hi.inc>
#include <clc/integer/gentype.inc>
