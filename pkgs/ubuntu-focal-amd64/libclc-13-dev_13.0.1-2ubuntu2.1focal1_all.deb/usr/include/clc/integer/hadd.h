#define __CLC_BODY <clc/integer/hadd.inc>
#include <clc/integer/gentype.inc>
