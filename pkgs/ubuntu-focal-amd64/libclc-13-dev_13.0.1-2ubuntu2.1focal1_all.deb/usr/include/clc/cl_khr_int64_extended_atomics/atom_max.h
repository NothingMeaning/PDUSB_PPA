#define __CLC_FUNCTION atom_max
#include <clc/atom_decl_int64.inc>
