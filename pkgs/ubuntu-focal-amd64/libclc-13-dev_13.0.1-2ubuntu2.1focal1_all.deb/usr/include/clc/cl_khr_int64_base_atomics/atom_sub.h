#define __CLC_FUNCTION atom_sub
#include <clc/atom_decl_int64.inc>
